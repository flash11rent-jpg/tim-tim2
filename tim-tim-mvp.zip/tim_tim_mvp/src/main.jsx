import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ShoppingBag, Search, MapPin, Clock3, Plus, Minus, ArrowLeft, Package, Store, Truck, ClipboardList, User, CheckCircle2 } from 'lucide-react';
import './style.css';

const initialStores = [
  {id:1,name:'У дома',category:'Продукты',time:'20–35 мин',delivery:99,tag:'Популярный',items:[
    {id:11,name:'Молоко 2,5%',unit:'1 л',price:89,emoji:'🥛'},
    {id:12,name:'Хлеб белый',unit:'1 шт.',price:49,emoji:'🍞'},
    {id:13,name:'Яйца С1',unit:'10 шт.',price:119,emoji:'🥚'},
    {id:14,name:'Бананы',unit:'1 кг',price:139,emoji:'🍌'},
    {id:15,name:'Сыр российский',unit:'200 г',price:189,emoji:'🧀'},
    {id:16,name:'Вода питьевая',unit:'1,5 л',price:59,emoji:'💧'}
  ]},
  {id:2,name:'Цветочная мастерская',category:'Цветы',time:'30–50 мин',delivery:149,tag:'Цветы',items:[
    {id:21,name:'Букет из 5 роз',unit:'букет',price:1490,emoji:'🌹'},
    {id:22,name:'Букет сезонный',unit:'букет',price:1990,emoji:'💐'},
    {id:23,name:'Тюльпаны',unit:'5 шт.',price:890,emoji:'🌷'}
  ]},
  {id:3,name:'Дом и быт',category:'Хозяйственные',time:'25–45 мин',delivery:99,tag:'Для дома',items:[
    {id:31,name:'Средство для посуды',unit:'500 мл',price:129,emoji:'🧴'},
    {id:32,name:'Губки',unit:'5 шт.',price:69,emoji:'🧽'},
    {id:33,name:'Бумажные полотенца',unit:'2 рулона',price:119,emoji:'🧻'}
  ]}
];
const money = n => new Intl.NumberFormat('ru-RU').format(n) + ' ₽';
function App(){
  const [stores] = useState(initialStores);
  const [page,setPage] = useState('home');
  const [category,setCategory] = useState('Все');
  const [query,setQuery] = useState('');
  const [storeId,setStoreId] = useState(null);
  const [cart,setCart] = useState({});
  const [orders,setOrders] = useState([]);
  const [address,setAddress] = useState('');
  const [phone,setPhone] = useState('');
  const [comment,setComment] = useState('');
  const [role,setRole] = useState('Покупатель');
  const [activeOrder,setActiveOrder] = useState(null);
  const currentStore = stores.find(s=>s.id===storeId);
  const cartItems = Object.values(cart);
  const cartStore = cartItems[0]?.storeId;
  const subtotal = cartItems.reduce((s,x)=>s+x.price*x.qty,0);
  const delivery = cartItems.length ? (stores.find(s=>s.id===cartStore)?.delivery || 0) : 0;
  const total = subtotal + delivery;
  const visibleStores = stores.filter(s=>(category==='Все'||s.category===category) && (s.name+s.category+s.items.map(i=>i.name).join(' ')).toLowerCase().includes(query.toLowerCase()));
  const count = cartItems.reduce((s,x)=>s+x.qty,0);
  function add(item,store){
    if(cartItems.length && cartStore!==store.id){ alert('В одном заказе могут быть товары только из одного магазина. Очистите корзину, чтобы выбрать другой магазин.'); return; }
    setCart(old=>({...old,[item.id]:{...item,qty:(old[item.id]?.qty||0)+1,storeId:store.id,storeName:store.name}}));
  }
  function change(id,delta){ setCart(old=>{const next={...old}; if(!next[id])return old; next[id].qty+=delta; if(next[id].qty<=0)delete next[id]; return next;}); }
  function checkout(){
    if(subtotal<700){alert('Минимальная сумма товаров — 700 ₽.');return;}
    if(!address.trim()||!phone.trim()){alert('Укажите адрес и телефон.');return;}
    const order={id:Date.now(),storeName:cartItems[0].storeName,items:cartItems.map(x=>({...x})),subtotal,delivery,total,address,phone,comment,status:'Новый',created:new Date().toLocaleString('ru-RU')};
    setOrders(old=>[order,...old]); setActiveOrder(order); setCart({}); setPage('success');
  }
  function setStatus(id,status){setOrders(old=>old.map(o=>o.id===id?{...o,status}:o));}
  const statuses=['Новый','Подтверждён','Собирается','Готов','В пути','Доставлен'];
  return <div className="app">
    <header className="top"><div className="brandmark">Тим-Тим<span>⌣</span></div><div className="topright"><span className="location"><MapPin size={15}/> Тимашевск</span><button className="role" onClick={()=>setRole(role==='Покупатель'?'Оператор':'Покупатель')}>{role==='Покупатель'?'Режим оператора':'Режим покупателя'}</button></div></header>
    {role==='Оператор' ? <main className="main">
      <div className="eyebrow">РАБОЧАЯ ПАНЕЛЬ</div><h1>Заказы</h1><p className="muted">Демонстрационный режим оператора. Заказы сохраняются только в этом браузере.</p>
      {orders.length===0?<div className="empty"><ClipboardList size={34}/><b>Пока нет заказов</b><span>Новые заказы появятся здесь после оформления.</span></div>:orders.map(o=><section className="order" key={o.id}><div className="orderhead"><b>Заказ #{String(o.id).slice(-5)}</b><span className="pill">{o.status}</span></div><p>{o.storeName} · {o.created}</p><p>{o.address} · {o.phone}</p><p>{o.items.map(i=>`${i.name} × ${i.qty}`).join(', ')}</p><b>{money(o.total)}</b><div className="statusrow"><select value={o.status} onChange={e=>setStatus(o.id,e.target.value)}>{statuses.map(s=><option>{s}</option>)}<option>Отменён</option></select></div></section>)}
    </main> : <>
    {page==='home'&&<main className="main">
      <section className="hero"><div><div className="eyebrow">ДОСТАВКА ПО ТИМАШЕВСКУ</div><h1>Покупки —<br/>без лишних дел.</h1><p>Выбирайте магазин. Мы привезём.</p></div><div className="heroart">🛍️</div></section>
      <label className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Найти магазин или товар"/></label>
      <div className="sectionhead"><h2>Категории</h2></div><div className="categories">{['Все','Продукты','Цветы','Хозяйственные'].map((c,i)=><button className={category===c?'cat active':'cat'} onClick={()=>setCategory(c)}><span>{['✦','🥑','🌷','🏠'][i]}</span>{c}</button>)}</div>
      <div className="sectionhead"><h2>Магазины</h2><span className="muted">{visibleStores.length} места</span></div>
      <div className="stores">{visibleStores.map(s=><button className="store" key={s.id} onClick={()=>{setStoreId(s.id);setPage('store')}}><div className="storeicon">{s.category==='Цветы'?'💐':s.category==='Хозяйственные'?'🧼':'🥑'}</div><div className="storeinfo"><b>{s.name}</b><span>{s.category} · {s.time}</span><small>Доставка от {money(s.delivery)}</small></div><span className="arrow">›</span></button>)}</div>
      <p className="notice">Цены, магазины и товары в этой версии — демонстрационные примеры.</p>
    </main>}
    {page==='store'&&<main className="main"><button className="back" onClick={()=>setPage('home')}><ArrowLeft size={17}/> Все магазины</button><div className="storehero"><div className="storeicon big">{currentStore?.category==='Цветы'?'💐':currentStore?.category==='Хозяйственные'?'🧼':'🥑'}</div><div><h1>{currentStore?.name}</h1><p className="muted">{currentStore?.category} · {currentStore?.time}</p></div></div><label className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Поиск по товарам"/></label><h2>Каталог</h2><div className="products">{currentStore?.items.filter(i=>i.name.toLowerCase().includes(query.toLowerCase())).map(i=><div className="product" key={i.id}><div className="productpic">{i.emoji}</div><div className="productdata"><b>{i.name}</b><span>{i.unit}</span><strong>{money(i.price)}</strong></div><button className="add" onClick={()=>add(i,currentStore)}><Plus size={19}/></button>{cart[i.id]&&<span className="qty">{cart[i.id].qty}</span>}</div>)}</div></main>}
    {page==='cart'&&<main className="main"><button className="back" onClick={()=>setPage('home')}><ArrowLeft size={17}/> Продолжить покупки</button><h1>Корзина</h1>{!cartItems.length?<div className="empty"><ShoppingBag size={34}/><b>Корзина пока пуста</b><span>Добавьте товары из магазина.</span></div>:<><p className="muted">{cartItems[0].storeName}</p>{cartItems.map(i=><div className="cartrow"><div><b>{i.name}</b><small>{money(i.price)} за {i.unit}</small></div><div className="stepper"><button onClick={()=>change(i.id,-1)}><Minus size={15}/></button><b>{i.qty}</b><button onClick={()=>change(i.id,1)}><Plus size={15}/></button></div><strong>{money(i.price*i.qty)}</strong></div>)}<div className="summary"><div><span>Товары</span><b>{money(subtotal)}</b></div><div><span>Доставка</span><b>{money(delivery)}</b></div><div className="grand"><span>Итого</span><b>{money(total)}</b></div></div><p className={subtotal<700?'warning':'muted'}>{subtotal<700?`До минимального заказа 700 ₽ осталось ${money(700-subtotal)}.`:'Минимальная сумма заказа выполнена.'}</p><button className="primary full" disabled={subtotal<700} onClick={()=>setPage('checkout')}>Оформить заказ</button></>}</main>}
    {page==='checkout'&&<main className="main"><button className="back" onClick={()=>setPage('cart')}><ArrowLeft size={17}/> Корзина</button><h1>Оформление</h1><div className="form"><label>Адрес доставки<input value={address} onChange={e=>setAddress(e.target.value)} placeholder="Улица, дом, квартира"/></label><label>Телефон<input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+7 (___) ___-__-__"/></label><label>Комментарий<textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Подъезд, этаж, домофон, пожелания"/></label></div><div className="summary"><div><span>Товары</span><b>{money(subtotal)}</b></div><div><span>Доставка</span><b>{money(delivery)}</b></div><div className="grand"><span>К оплате при получении</span><b>{money(total)}</b></div></div><p className="muted tiny">Наличие и окончательные цены подтверждаются магазином. Онлайн-оплата пока не подключена.</p><button className="primary full" onClick={checkout}>Подтвердить заказ</button></main>}
    {page==='success'&&<main className="main success"><CheckCircle2 size={54}/><h1>Заказ принят!</h1><p>Заказ передан оператору. Мы свяжемся с вами для подтверждения.</p><div className="successbox"><b>{activeOrder?.storeName}</b><span>{money(activeOrder?.total||0)}</span><small>{activeOrder?.address}</small></div><button className="primary full" onClick={()=>setPage('orders')}>Мои заказы</button><button className="textbtn" onClick={()=>setPage('home')}>На главную</button></main>}
    {page==='orders'&&<main className="main"><h1>Мои заказы</h1>{orders.length===0?<div className="empty"><Package size={34}/><b>Заказов пока нет</b></div>:orders.map(o=><div className="order"><div className="orderhead"><b>Заказ #{String(o.id).slice(-5)}</b><span className="pill">{o.status}</span></div><p>{o.storeName}</p><b>{money(o.total)}</b></div>)}</main>}
    {page==='profile'&&<main className="main"><h1>Профиль</h1><div className="profilecard"><User size={24}/><b>Покупатель</b><span className="muted">Тимашевск</span></div><div className="order"><b>Помощь и поддержка</b><p>Контакты службы поддержки будут добавлены перед запуском.</p></div></main>}
    <nav className="bottom"><button className={page==='home'||page==='store'?'selected':''} onClick={()=>setPage('home')}><Store/><span>Магазины</span></button><button className={page==='cart'?'selected':''} onClick={()=>setPage('cart')}><span className="navicon"><ShoppingBag/>{count>0&&<i>{count}</i>}</span><span>Корзина</span></button><button className={page==='orders'?'selected':''} onClick={()=>setPage('orders')}><ClipboardList/><span>Заказы</span></button><button className={page==='profile'?'selected':''} onClick={()=>setPage('profile')}><User/><span>Профиль</span></button></nav>
    </>}
    <footer>ТИМ-ТИМ <span>Доставка из магазинов · Тимашевск</span></footer>
  </div>
}
createRoot(document.getElementById('root')).render(<App/>);
